//bai1 a
const a = [1, 2, 3, 4, 5]; // Ví dụ array

const sum = a.reduce((acc, curr) => acc + curr, 0);
console.log("Tổng các phần tử của a:", sum);
//b
const m = 2; // Số m
const n = 4; // Số n

const filteredAndSorted = a.filter(num => num >= m && num <= n).sort((x, y) => x - y);
console.log("Các phần tử nằm trong khoảng [m..n]:", filteredAndSorted);

//c
const isPrime = (num) => {
    if (num < 2) return false;
    for (let i = 2; i <= Math.sqrt(num); i++) {
        if (num % i === 0) return false;
    }
    return true;
};

const primesInA = a.filter(isPrime);
console.log("Các số nguyên tố trong a:", primesInA);




