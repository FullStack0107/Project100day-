
//a. Sử dụng map để bình phương toàn bộ các phần tử trong array
        const arr = [1, 2, 3, 4, 5]; // Ví dụ array

const squared = arr.map(num => num * num);
console.log("Các phần tử bình phương:", squared);

//b.Đếm số lượng ước của các số trong arr, sau đó lưu vào một array mới
const countDivisors = (num) => {
    let count = 0;
    for (let i = 1; i <= num; i++) {
        if (num % i === 0) count++;
    }
    return count;
};

const divisorsCountArray = arr.map(countDivisors);
console.log("Số lượng ước của các số trong arr:", divisorsCountArray);
  