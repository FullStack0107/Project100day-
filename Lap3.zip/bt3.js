//Arrow function kiểm tra xem một số có phải là số nguyên tố hay không
const isPrimeArrow = (num) => {
    if (num < 2) return false;
    for (let i = 2; i <= Math.sqrt(num); i++) {
        if (num % i === 0) return false;
    }
    return true;
};

// In ra các số nguyên tố từ 1 đến 10
for (let i = 1; i <= 10; i++) {
    if (isPrimeArrow(i)) {
        console.log(`${i} là số nguyên tố`);
    }
}