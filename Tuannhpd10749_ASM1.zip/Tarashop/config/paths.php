<?php
	define('URL', 'http://localhost/PHP/Tarashop/');
?>
