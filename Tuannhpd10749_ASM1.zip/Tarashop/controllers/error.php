<?php
class _error{
	 function __construct(){
		echo" Loi contrller không tồn tại ";
	}
}
	?>