<?php
require "libs/Uri.php";
require "libs/Controller.php";
require "libs/View.php";
require "Config/Database.php";
require "libs/Database.php";
require "libs/Model.php";
require "Config/Paths.php";
require "libs/Pagination.php";
require "libs/File.php";
$Uri= new Uri();
?>