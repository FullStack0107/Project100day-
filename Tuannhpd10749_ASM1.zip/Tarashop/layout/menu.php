<li class="nav-item active">
                            <a class="nav-link" href="<?= URL ?>index.php/home">TRANG CHỦ <span class="sr-only">(current)</span></a>
                        </li>
                           <li class="nav-item">
                            <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">ÁO</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">VÁY</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">QUẦN</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">LIÊN HỆ</a>
                        </li>