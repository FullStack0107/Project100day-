
<?php
class Backend_Model extends Model{
	 function __construct(){
	 	parent::__construct();
	 	echo " Đây là backend model ! ";
	 }
}

?>