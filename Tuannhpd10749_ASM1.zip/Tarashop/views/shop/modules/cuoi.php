 <!-- <div class="featured">
                        <ul>
                            <li><a href="index.html"><img src="<?php echo URL?>public/images/organic-and-chemical-free.jpg" width="300" height="90" alt="Pet Shop" title="Pet Shop" ></a></li>
                            <li><a href="index.html"><img src="<?php echo URL?>public/images/good-food.jpg" width="300" height="90" alt="Pet Shop" title="Pet Shop" ></a></li>
                            <li class="last"><a href="index.html"><img src="<?php echo URL?>public/images/pet-grooming.jpg" width="300" height="90" alt="Pet Shop" title="Pet Shop" ></a></li>
                        </ul>
                        
                   </div>
                  
            
            </div>
            
            <div id="footer">
                    <div class="section">
                        <ul>
                            <li>
                                <img src="<?php echo URL?>public/images/friendly-pets.jpg" width="240" height="186" alt="Pet Shop" title="Pet Shop">
                                <h2><a href="index.html">Friendly Pets</a></h2>
                                <p>
                                   Lorem ipsum dolor sit amet, consectetuer adepiscing elit,  sed diam nonummy nib. <a class="more" href="index.html">Read More</a> 
                                </p>
                            </li>   
                            <li>
                                <img src="<?php echo URL?>public/images/pet-lover2.jpg" width="240" height="186" alt="Pet Shop" title="Pet Shop">
                                <h2><a href="index.html">How dangerous are they</a></h2>
                                <p>
                                   Lorem ipsum dolor sit amet, cons ectetuer adepis cing, sed diam euis. <a class="more" href="index.html">Read More</a> 
                                </p>
                            </li>   
                            <li>
                                <img src="<?php echo URL?>public/images/healthy-dog.jpg" width="240" height="186" alt="Pet Shop" title="Pet Shop">
                                <h2><a href="index.html">Keep them healthy</a></h2>
                                <p>
                                   Lorem ipsum dolor sit amet, consectetuer adepiscing elit,  sed diam nonu mmy. <a class="more" href="index.html">Read More</a> 
                                </p>
                            </li>   
                            <li>
                                
                                <h2><a href="index.html">Love...love...love...pets</a></h2>
                                <p>
                                     Lorem ipsum dolor sit amet, consectetuer adepiscing elit,  sed diameusim. <a class="more" href="index.html">Read More</a> 
                                </p>
                                <img src="<?php echo URL?>public/images/pet-lover.jpg" width="240" height="186" alt="Pet Shop" title="Pet Shop">
                            </li>   
                        </ul>
                    </div>
                    <div id="footnote">
                        <div class="section">
                           &copy; 2011 <a href="index.html">Petshop</a>. All Rights Reserved.
                        </div>
                    </div>
            </div>
            
    

</body>
</html> -->
