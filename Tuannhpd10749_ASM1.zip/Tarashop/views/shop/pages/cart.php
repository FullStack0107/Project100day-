<div class="card text-center">
    <div class="card-header">
        SẢN PHẨM <!-- Phần tiêu đề của thẻ card hiển thị "SẢN PHẨM" -->
    </div>
    <div class="card-body p-0">
        <?php
        $i=1;
        // Kiểm tra xem giỏ hàng có tồn tại không
        if (isset($_SESSION['cart'])){
            // Lặp qua từng sản phẩm trong giỏ hàng
            foreach($_SESSION['cart'] as $pro){
        ?>
        <div class="d-flex">
            <div class="p-2 border"><?=$i?></div> <!-- Hiển thị số thứ tự sản phẩm -->
            <div class="p-2 border  col-4 "><?= $pro['product_name'] ?></div> <!-- Hiển thị tên sản phẩm -->
            <div class="p-2 border col-3 border text-center">
                <div class="input-group">
                    <!-- Nút giảm số lượng sản phẩm -->
                    <a href="<?=URL?>index.php/home/cartunplus/<?= $pro['id'] ?>" class="input-group-text btn btn-danger"> - </a>
                    <!-- Ô nhập số lượng sản phẩm -->
                    <input type="number" value="<?= $pro['quantity'] ?>" class="form-control text-center" min="1" max="100">
                    <!-- Nút tăng số lượng sản phẩm -->
                    <a href="<?=URL?>index.php/home/cartplus/<?= $pro['id'] ?>" class="input-group-text btn btn-success"> + </a>
                </div>
            </div>
            <div class="p-2 border col-2 border text-end"><?=number_format($pro["price"]*$pro['quantity'] , 0, '', ',') ?> VNĐ</div> <!-- Hiển thị tổng giá tiền của sản phẩm -->
            <div class="p-2 border flex-grow-1 text-end">
                <!-- Nút xóa sản phẩm khỏi giỏ hàng -->
                <a href="<?=URL?>index.php/home/deleteOneCart/<?= $pro['id'] ?>" class="btn btn-default">
                    <i class="bi bi-trash"></i>
                </a>
            </div>
        </div>
        <?php
            $i++; // Tăng số thứ tự sản phẩm
            }
        }
        else {
            // Hiển thị thông báo nếu giỏ hàng trống
            echo "<h2 style='text-align:center;margin:1rem 0;'>Giỏ hàng trống</h2>";
        }
        ?>
    </div>
    <!-- Hiển thị tổng giá trị giỏ hàng -->
    <a>Totalcart <?=number_format($_SESSION['total'], 0, '', ',') ?>VNĐ</a>
    <div class="card-footer text-muted">
        <!-- Nút xóa tất cả sản phẩm trong giỏ hàng -->
        <a href="<?= URL ?>index.php/home/deleteAllCart" class="btn btn-outline-danger">Delete ALL PRO</a>
        <!-- Nút đặt hàng -->
        <a href="<?= URL ?>index.php/home/thanhtoan" class="btn btn-outline-success">Đặt hàng</a>
    </div>
</div>
