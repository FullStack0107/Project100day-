<?php
require("public/function/function.php"); // Yêu cầu tệp chức năng

?>

<div class="h3 mb-5">Sản phẩm</div>
<div class="row">
    <div class="col-10 row">
        <?php
        // Kiểm tra xem có sản phẩm nào trong danh mục không
        if (count($data["product_cate"])==0){
            echo "<div class='h1 text-warning'>Không có sản phẩm vui lòng chọn danh mục khác</div>";
        }
        else
        {
            // Lặp qua từng sản phẩm trong danh sách sản phẩm
            foreach ($data["product_ed"] as $value) {
                echo "<div class='col-lg-4 col-md-6 col-sm-6 col-6 mt-3'>";
                echo "<div class='card product p-2' style='width:auto'>";
                
                // Hiển thị hình ảnh sản phẩm với liên kết chi tiết sản phẩm
                echo "<a href='".URL."index.php/home/details/".$value["id"]."'><img class='proo card-img-top' src='".URL."public/img/" . $value["image"] . "' alt='" . $value["image"] . "'></a>";
                
                // Hiển thị tên sản phẩm với liên kết chi tiết sản phẩm
                echo "<div class='card-title product-title text-center h5'><a href='".URL."index.php/home/details/".$value["id"]."' class='proo'>" . $value["product_name"] . "</a></div>";
                
                // Hiển thị giá sản phẩm
                echo "<div class='price text-center h6'>" . number_format($value["price"], 0, '', ',') . " VNĐ</div>";
                
                // Hiển thị nút thêm vào giỏ hàng
                echo "<span class='text-center add-to-cart add-cart btn btn-outline-warning' onclick='tks()'>";
                echo "<a href='".URL."index.php/home/addcart/".$value["id"]."'>";
                echo "<i class='fas fa-cart-plus'></i>";
                echo " </a>";
                echo " </span>";
                echo "</div>";
                echo " </div>";
            }
        }
        ?>
    </div>

    <div class="col-2 menu-right">
        <?php $this->view("shop/modules/sidebar",$data); // Hiển thị thanh menu bên phải ?>
    </div>
</div>

<?php 
// Kiểm tra xem có sản phẩm nào trong danh sách sản phẩm không
if (count($data["product_ed"])>0) {
?>

<?= $data['paginator'] ?> <!-- Hiển thị phân trang -->

<?php 
}
?>

</div>
