<?php
// Lấy chi tiết sản phẩm từ biến $data
$product = $data["details"];
?>
<div class="container p-0 chitietsanpham">
    <h3>Sản phẩm/<?= $product["product_name"] ?></h3> <!-- Tiêu đề sản phẩm -->
    <div class="sanpham">
        <div class="hinhanh mt-3">
            <img src="<?= URL ?>public/img/<?= $product["image"] ?>" alt=""> <!-- Hình ảnh sản phẩm -->
            <div class="mt-4 mb-4"><?= $product["product_detail"]; ?></div> <!-- Chi tiết sản phẩm -->
        </div>
        <div class="content mt-3">
            <div class="title">
                <div href="#" class="title-name h5"><?= $product["product_name"] ?></div> <!-- Tên sản phẩm -->
                <div class="title-ma">Mã sản phẩm:<b><?= $product["id"] ?></b> </div> <!-- Mã sản phẩm -->
                <div class="title-trangthai">Còn hàng</div> <!-- Trạng thái sản phẩm -->
            </div> 
            <div class="price"><?= number_format($product["price"], 0, '', ',') ?> VNĐ</div> <!-- Giá sản phẩm -->
            <a href="<?=URL?>index.php/home/addcart/<?=$product["id"]?> " class="btn btn-primary themhang">Thêm vào giỏ</a> <!-- Nút thêm vào giỏ hàng -->

            <div class="content-footer">
                <div class="giaohang">
                    <div><i class="fas fa-truck"></i></div> <!-- Biểu tượng giao hàng -->
                    <div class="giaohang-content">
                        <h4>MIỄN PHÍ GIAO HÀNG TOÀN QUỐC</h4> <!-- Tiêu đề miễn phí giao hàng -->
                        <p>(Sản phẩm trên 300,000đ)</p> <!-- Điều kiện miễn phí giao hàng -->
                    </div>
                </div>
                <div class="giaohang">
                    <div><i class="fas fa-file-invoice"></i></div> <!-- Biểu tượng đổi trả -->
                    <div class="giaohang-content">
                        <h4>ĐỔI TRẢ DỄ DÀNG</h4> <!-- Tiêu đề đổi trả dễ dàng -->
                        <p>(Đổi trả 24h cho tất cả sản phẩm đầy đủ tem mác)</p> <!-- Điều kiện đổi trả -->
                    </div>
                </div>
                <div class="giaohang">
                    <div><i class="fas fa-phone-alt"></i></div> <!-- Biểu tượng tổng đài bán hàng -->
                    <div class="giaohang-content">
                        <h4>TỔNG ĐÀI BÁN HÀNG 1800 1162</h4> <!-- Tiêu đề tổng đài bán hàng -->
                        <p>(Miễn phí từ 8h30 - 21:30 mỗi ngày)</p> <!-- Giờ hoạt động của tổng đài -->
                    </div>           
                </div>
            </div>
        </div>
    </div>
</div>
