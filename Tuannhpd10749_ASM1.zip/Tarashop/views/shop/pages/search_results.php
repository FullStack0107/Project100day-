<h2>Search Results for "<?php echo htmlspecialchars($search_query); ?>"</h2>

<?php if (empty($search_results)): ?>
    <p>No results found.</p>
<?php else: ?>
    <ul>
    <?php foreach ($search_results as $product): ?>
        <li>
            <h3><?php echo htmlspecialchars($product['product_name']); ?></h3>
            <p><?php echo htmlspecialchars($product['description']); ?></p>
            <p>Price: $<?php echo number_format($product['price'], 2); ?></p>
            <a href="<?php echo URL . 'index.php/home/details/' . $product['id']; ?>">View Details</a>
        </li>
    <?php endforeach; ?>
    </ul>
<?php endif; ?>
<form action="<?php echo URL; ?>index.php/home/search" method="GET">
    <input type="text" name="query" placeholder="Search for products..." required>
    <button type="submit">Search</button>
</form>