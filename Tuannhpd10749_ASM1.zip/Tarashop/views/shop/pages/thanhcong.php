<h2 style="text-align: center;" class="text-center">ĐẶT HÀNG THÀNH CÔNG</h2>
<a style="text-align: center;" href="<?= URL ?>index.php/home">Về trang chủ</a>