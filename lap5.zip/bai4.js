class Person {
    constructor(firstname, lastname) {
        this._firstname = firstname;
        this._lastname = lastname;
    }

    set lastname(value) {
        this._lastname = value;
    }

    set firstname(value) {
        this._firstname = value;
    }

    get fullName() {
        return `${this._firstname} ${this._lastname}`;
    }
}

const person = new Person('Albert', 'Einstein');
person.lastname = 'Newton';
person.firstname = 'Issac';

console.log(person.fullName); // Output: Issac Newton