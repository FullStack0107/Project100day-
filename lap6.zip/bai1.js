// Định nghĩa hàm uppercaseString
export const uppercaseString = (string) => {
    return string.toUpperCase();
};

// Định nghĩa hàm lowercaseString
export const lowercaseString = (string) => {
    return string.toLowerCase();
};

import { uppercaseString, lowercaseString } from './path/to/your/module';

// Sử dụng các hàm
console.log(uppercaseString('hello')); // Output: HELLO
console.log(lowercaseString('WORLD')); // Output: world