// module.js
export const uppercaseString = (string) => {
    return string.toUpperCase();
};

export const lowercaseString = (string) => {
    return string.toLowerCase();
};

// main.js
import * as stringFunctions from './module.js';

console.log(stringFunctions.uppercaseString("hello")); // Output: HELLO
console.log(stringFunctions.lowercaseString("WORLD!")); // Output: world!