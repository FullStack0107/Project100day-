function subtract(x, y) {
    return x - y;
}

console.log(subtract(10, 5)); // Output: 5
console.log(subtract(20, 8)); // Output: 12