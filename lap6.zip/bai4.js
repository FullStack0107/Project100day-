// sum_function.js
const subtract = (x, y) => {
    return x - y;
};

export default subtract;

// main.js
import subtract from './sum_function.js';

const result = subtract(7, -4); // Kết quả mong muốn là 11
console.log(result); // Output: 11