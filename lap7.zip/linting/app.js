const name = 'James'
const person = {first : name}
console.log(person)
const sayHellolinting = (fname) => {
    console.log(`Hello linting, ${fname}!`)
};

sayHellolinting('James');